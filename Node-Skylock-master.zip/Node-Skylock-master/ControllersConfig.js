
var User = require('./controllers/api/UserController');
var user = new User();

var Account = require('./controllers/api/AccountController');
var account = new Account();