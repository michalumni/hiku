//
//  BikesViewController.h
//  Skylock
//
//  Created by Daniel Ondruj on 04.04.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BikesViewController : UIViewController

@end
