//
//  SkylockSetupCongratulationsViewController.h
//  Skylock
//
//  Created by Daniel Ondruj on 24.03.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SkylockSetupCongratulationsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *closeButton;
- (IBAction)closeButtonAction:(id)sender;

@end
