//
//  CDBike.m
//  Skylock
//
//  Created by Daniel Ondruj on 14.04.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import "CDBike.h"
#import "CDUser.h"


@implementation CDBike

@dynamic bike_id;
@dynamic brand;
@dynamic color;
@dynamic frame;
@dynamic image;
@dynamic model;
@dynamic name;
@dynamic note;
@dynamic purchase_date;
@dynamic serial_number;
@dynamic speeds;
@dynamic user_id;
@dynamic imageURL;
@dynamic owner;

@end
