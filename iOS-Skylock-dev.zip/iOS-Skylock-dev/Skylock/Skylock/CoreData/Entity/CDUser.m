//
//  CDUser.m
//  Skylock
//
//  Created by Daniel Ondruj on 14.04.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import "CDUser.h"
#import "CDBike.h"
#import "CDLock.h"
#import "CDUsers.h"


@implementation CDUser

@dynamic api_token;
@dynamic avatar;
@dynamic birth;
@dynamic email;
@dynamic first_name;
@dynamic gender;
@dynamic last_name;
@dynamic passwod;
@dynamic phone;
@dynamic user_id;
@dynamic avatarURL;
@dynamic bikes;
@dynamic inDatabase;
@dynamic locks;

@end
