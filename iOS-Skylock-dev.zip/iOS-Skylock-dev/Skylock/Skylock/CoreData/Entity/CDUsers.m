//
//  CDUsers.m
//  Skylock
//
//  Created by Daniel Ondruj on 10.04.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import "CDUsers.h"
#import "CDUser.h"


@implementation CDUsers

@dynamic users;

@end
