//
//  CDLock.m
//  Skylock
//
//  Created by Daniel Ondruj on 10.04.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import "CDLock.h"
#import "CDUser.h"


@implementation CDLock

@dynamic lock_id;
@dynamic isDefault;
@dynamic isLocked;
@dynamic localBTID;
@dynamic locationLatitude;
@dynamic locationLongitude;
@dynamic name;
@dynamic user_id;
@dynamic owner;

@end
