//
//  ViewController.h
//  Skylock
//
//  Created by Daniel Ondruj on 18.03.14.
//  Copyright (c) 2014 uLikeIT s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
