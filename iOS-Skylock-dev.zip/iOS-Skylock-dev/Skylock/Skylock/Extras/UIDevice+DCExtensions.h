//
//  UIDevice+DCExtensions.h
//  AAA
//
//  Created by Dan on 03.05.13.
//  Copyright (c) 2013 uLikeIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (DCExtensions)

+ (BOOL)isIPhone5Screen;

@end
