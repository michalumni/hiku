//
//  NetworkingClient.h
//  Hungry
//
//  Created by Martin Stava on 9/19/13.
//  Copyright (c) 2013 Martin Stava. All rights reserved.
//

#import <AFHTTPRequestOperationManager.h>

@interface NetworkingClient : AFHTTPRequestOperationManager

@end
